

declare var jQuery:any;

