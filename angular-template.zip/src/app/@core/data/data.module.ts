import { NgModule, ModuleWithProviders, APP_INITIALIZER, Inject } from '@angular/core';
import { CommonModule } from '@angular/common';

import { GlobalEventsManager } from './global-events-manager';
import { UserService } from './users.service';
import { I18nService } from './I18nService';


export function sessionResolveFactory() {
  // sessionStorage or localStorage can be configured here
  return sessionStorage;
}

export function setupTranslateFactory(
  service: I18nService) {
  const language: string = sessionStorage.getItem('language') || 'en';
  return () => service.use(language);
}

const SERVICES = [
  GlobalEventsManager,
  {
    provide: 'Store',
    useFactory: sessionResolveFactory,
  },
  UserService,
  I18nService,
  {
    provide: APP_INITIALIZER,
    useFactory: setupTranslateFactory,
    deps: [I18nService],
    multi: true
  },
];

@NgModule({
  imports: [
    CommonModule,
  ],
  providers: [
    ...SERVICES,
  ],
})
export class DataModule {
  static forRoot(): ModuleWithProviders {
    return {
      ngModule: DataModule,
      providers: [
        ...SERVICES,
      ],
    } as ModuleWithProviders;
  }
}
