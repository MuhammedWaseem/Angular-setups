import { Injectable, Inject } from '@angular/core';
import { HttpClient, HttpBackend } from '@angular/common/http';
import { forkJoin } from 'rxjs';

@Injectable()
export class I18nService {
    public translationData: any = {};
    private httpClient: HttpClient;

    constructor(
        handler: HttpBackend,
        @Inject('Store') private store: Storage
    ) {
        this.httpClient = new HttpClient(handler);
    }

    use(languageKey: string): Promise<{}> {
        return new Promise<{}>((resolve, reject) => {
            if (!languageKey) {
                languageKey = this.store.get('language');
            }
            const languagePath = `/assets/i18n/${languageKey || 'en'}.json`;
            this.httpClient.get<{}>(languagePath)
                .subscribe(
                    translations => {
                        this.translationData = translations;
                        resolve(translations);
                    },
                    error => {
                        this.translationData = {};
                        console.error('Translations Error: ', error);
                        resolve(this.translationData);

                    }
                );
        });
    }
    public getTranslationsByPageName(pageName: string) {
        return this.translationData[pageName];
    }

}
