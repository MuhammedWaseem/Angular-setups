
import { of as observableOf, Observable } from 'rxjs';
import { Injectable, Inject } from '@angular/core';

@Injectable()
export class UserService {

  constructor(
    @Inject('Store') private store: Storage
  ) {
  }

  getCurrentLanguage$(): Observable<string> {
    const language = this.store.getItem('language') || 'en';
    return observableOf(language);
  }

  getCurrentLanguage(): string {
    return this.store.getItem('language') || 'en';
  }

  setCurrentLanguage(language: string) {
    this.store.setItem('language', language);
  }
  removeCurrentLanguage() {
    this.store.removeItem('language');
    return true;
  }
}
