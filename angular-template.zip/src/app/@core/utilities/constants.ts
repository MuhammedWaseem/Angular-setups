export const fteList = [{ 'id': 0.25, 'name': '0.25' },
{ 'id': 0.50, 'name': '0.50' },
{ 'id': 0.75, 'name': '0.75' },
{ 'id': 1.0, 'name': '1.0' }];
