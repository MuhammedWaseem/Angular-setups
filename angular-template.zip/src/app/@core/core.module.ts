import { ModuleWithProviders, NgModule, Optional, SkipSelf, ErrorHandler } from '@angular/core';
import { CommonModule } from '@angular/common';
import { of as observableOf } from 'rxjs';

import { throwIfAlreadyLoaded } from './module-import-guard';
import { DataModule } from './data/data.module';
import { HttpClientModule } from '@angular/common/http';
import { HttpUtility } from './utilities/http/http-utility.service';
import { CustomExceptionHandler } from './utilities/exception-handler/custom-exception-handler';


export const CORE_PROVIDERS = [
  HttpUtility,
  
  { provide: ErrorHandler, useClass: CustomExceptionHandler }
];

@NgModule({
  imports: [
    CommonModule,
    DataModule,
    HttpClientModule
  ],
  exports: [
  ],
  providers: [
    CORE_PROVIDERS
  ],
  declarations: [],
})
export class CoreModule {
  constructor(@Optional() @SkipSelf() parentModule: CoreModule) {
    throwIfAlreadyLoaded(parentModule, 'CoreModule');
  }

  static forRoot(): ModuleWithProviders {
    return {
      ngModule: CoreModule,
      providers: [
        ...CORE_PROVIDERS,
      ],
    } as ModuleWithProviders;
  }
}
