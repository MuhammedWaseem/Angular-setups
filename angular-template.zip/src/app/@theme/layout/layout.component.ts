import { UserService } from './../../@core/data/users.service';
import {
  Component,
  NgZone,
  OnInit,
  ViewContainerRef,
  ViewEncapsulation,
  AfterViewInit,
  Input,
} from '@angular/core';
import { GlobalEventsManager } from '@core/data/global-events-manager';
import { I18nService } from '@core/data/I18nService';
import { TranslateService } from '@ngx-translate/core';

/*
 * Layout Component
 * Top Level Component
 */
@Component({
  selector: 'app-layout',
  encapsulation: ViewEncapsulation.None,
  templateUrl: './layout.component.html',
  styleUrls: ['../styles/styles.scss']
})
export class LayoutComponent implements AfterViewInit, OnInit {



  public currentYear: number;
  public currentLanguage: string;

  constructor(private i18nService: I18nService,
              private translate: TranslateService,
              private userService: UserService
  ) {
    this.currentLanguage = this.userService.getCurrentLanguage();
    const layoutPageTranslations = this.i18nService.getTranslationsByPageName('layoutTranslations');
    this.translate.setTranslation(this.currentLanguage, layoutPageTranslations, true);
  }
  ngOnInit(): void {
  }

  ngAfterViewInit(): void {

  }
}
