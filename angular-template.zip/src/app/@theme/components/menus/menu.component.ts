
import {
    Component,
    EventEmitter,
    Input,
    Output,
    ViewEncapsulation,
    OnInit,
    OnDestroy
} from '@angular/core';
import { NavigationEnd, Router, Route } from '@angular/router';

import { Subscription } from 'rxjs';
import { MenuService } from './menu.service';
import { MENU } from './menu';
import { GlobalEventsManager } from '@core/data/global-events-manager';

@Component({
    selector: 'app-header-menu',
    styleUrls: ['./menu.scss'],
    templateUrl: './menu.html',
    providers: [MenuService]
})
export class MenuComponent implements OnInit {

    @Input() public menuItems: Array<any>;
    constructor(
        private globalEventsManger: GlobalEventsManager,
        private menuService: MenuService
    ) {
    }
    ngOnInit(): void {
        this.menuService.getMenuItems().subscribe((menus) => {
            this.menuItems = menus;
        });
    }

}
