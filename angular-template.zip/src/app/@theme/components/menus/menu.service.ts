import { Injectable } from '@angular/core';
import { Router, Routes } from '@angular/router';
import { HttpUtility } from '@core/utilities/http/http-utility.service';
import { Observable } from 'rxjs';

@Injectable()
export class MenuService {

    constructor(private http: HttpUtility) {
    }

    getMenuItems(): Observable<any> {
        return this.http.get('/assets/data/menu.json');
    }
}
