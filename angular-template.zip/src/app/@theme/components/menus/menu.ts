export const MENU = [
    {
        path: 'dashboard',
        data: {
            menu: {
                title: 'Dashboard',
                icon: 'fa-dashboard',
                selected: false,
                expanded: false,
                order: 30
            }
        }
    },
    {
        path: 'user',
        data: {
            menu: {
                title: 'User',
                icon: 'fa-user',
                selected: false,
                expanded: false,
                order: 0
            }
        }
    },
    {
        path: 'team',
        data: {
            menu: {
                title: 'Team',
                icon: 'fa-users',
                selected: false,
                expanded: false,
                order: 0
            }
        }
    },
    {
        path: 'agency',
        data: {
            menu: {
                title: 'Agency',
                icon: 'fa-university',
                selected: false,
                expanded: false,
                order: 0
            }
        }
    },
    {
        path: 'fund',
        data: {
            menu: {
                title: 'Fund',
                icon: 'fa-money',
                selected: false,
                expanded: false,
                order: 0
            }
        }
    }
];
