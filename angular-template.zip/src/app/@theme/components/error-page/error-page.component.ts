import { GlobalEventsManager } from '@core/data/global-events-manager';
import { Component, OnInit } from '@angular/core';

@Component({
    templateUrl: './error-page.component.html',
    styleUrls: ['./error-page.component.scss']
})

export class ErrorPageComponent implements OnInit {
    public statusCode: string;
    constructor(private globalEventsManager: GlobalEventsManager) {
    }
    ngOnInit(): void {
        this.globalEventsManager.errorStateHandler.subscribe((status) => {
            if (status != null) {
                console.error('ErrorPageComponent-', status);
                this.statusCode = status;
            } else {
                this.statusCode = null;
            }
        });
    }
}
