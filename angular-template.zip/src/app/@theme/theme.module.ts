import { TranslateModule, TranslatePipe } from '@ngx-translate/core';
import { ModuleWithProviders, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { LayoutComponent } from './layout/layout.component';
import { RouterModule } from '@angular/router';
import { HeaderComponent } from './components/header/header.component';
import { ErrorPageComponent } from './components/error-page/error-page.component';
import { LoaderComponent } from './components/loader/loader.component';
import { FooterComponent } from './components/footer/footer.component';
import { platformBrowserDynamic, } from '@angular/platform-browser-dynamic';
import { MenuComponent } from './components/menus/menu.component';
import { MenuService } from './components/menus/menu.service';

const BASE_MODULES = [
  CommonModule,
  FormsModule,
  ReactiveFormsModule,
  RouterModule
];

const COMPONENTS = [
  HeaderComponent,
  LoaderComponent,
  ErrorPageComponent,
  LayoutComponent,
  FooterComponent,
  MenuComponent
];


@NgModule({
  imports: [...BASE_MODULES, TranslateModule],
  exports: [...BASE_MODULES, TranslateModule, ...COMPONENTS],
  entryComponents: [LayoutComponent],
  declarations: [...COMPONENTS],
  providers: [
    MenuService
  ]
})
export class ThemeModule {
  static forRoot(): ModuleWithProviders {
    return {
      ngModule: ThemeModule,
    } as ModuleWithProviders;
  }
}
