import { Component, OnInit } from '@angular/core';
import { I18nService } from '@core/data/I18nService';
import { TranslateService } from '@ngx-translate/core';
import { UserService } from '@core/data/users.service';
import { Title } from '@angular/platform-browser';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {

  constructor(private i18nService: I18nService,
    private translate: TranslateService,
    private userService: UserService,
    private titleService: Title
  ) {
    const currentLanguage = this.userService.getCurrentLanguage();
    const dashboardPageTranslations = this.i18nService.getTranslationsByPageName('GlobalTranslations');
    this.translate.setTranslation(currentLanguage, dashboardPageTranslations, true);
    this.translate.use(currentLanguage);
    this.titleService.setTitle(this.translate.instant('TITLE'));
  }

  ngOnInit(): void {
  }

}
