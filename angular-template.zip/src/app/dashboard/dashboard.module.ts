import { ReactiveFormsModule } from '@angular/forms';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DashboardComponent } from './dashboard.component';
import { SignUpComponent } from './components/sign-up/sign-up.component';
import { ArticlesComponent } from './components/articles/articles.component';
import { FeaturedProductComponent } from './components/featured-product/featured-product.component';
import { DashboardRoutingModule } from './dashboard.routing';
import { DashboardService } from './dashboard.service';
import { TranslateModule } from '@ngx-translate/core';


@NgModule({
  declarations: [
    DashboardComponent,
    SignUpComponent,
    ArticlesComponent,
    FeaturedProductComponent
  ],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    DashboardRoutingModule,
    TranslateModule
  ],
  providers: [
    DashboardService
  ]
})
export class DashboardModule { }
