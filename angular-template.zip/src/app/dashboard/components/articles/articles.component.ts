import { Component, OnInit } from '@angular/core';
import { DashboardService } from '../../dashboard.service';

@Component({
  selector: 'app-articles',
  templateUrl: './articles.component.html',
  styleUrls: ['./articles.component.scss']
})
export class ArticlesComponent implements OnInit {

  public articles: Array<any>;
  constructor(private dashboardService: DashboardService) { }


  ngOnInit(): void {
    this.dashboardService.getJsonBasedOnFileName('/assets/data/articles.json').subscribe(data => {
      if (data) {
        this.articles = data;
      }
    });
  }

}
