import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-sign-up',
  templateUrl: './sign-up.component.html',
  styleUrls: ['./sign-up.component.scss']
})
export class SignUpComponent implements OnInit {

  public registrationForm: FormGroup;
  constructor(private formBuilder: FormBuilder) {
    this.buildForm();
  }

  ngOnInit(): void {
  }

  private buildForm(): void {
    this.registrationForm = this.formBuilder.group({
      email: ['', Validators.compose([Validators.required])],
      firstName: ['', Validators.compose([Validators.required
        , Validators.minLength(3), Validators.maxLength(40)])
      ],
      surName: ['', Validators.compose([Validators.required
        , Validators.minLength(3), Validators.maxLength(40)
      ])]
    });
  }

  registrationFormSubmit() {
    if (this.registrationForm.valid) {
      console.log('SIGN UP FORM:', this.registrationForm.getRawValue())
    }
  }
}
