import { Component, OnInit, AfterViewInit } from '@angular/core';
import { DashboardService } from '../../dashboard.service';

@Component({
  selector: 'app-featured-product',
  templateUrl: './featured-product.component.html',
  styleUrls: ['./featured-product.component.scss']
})
export class FeaturedProductComponent implements OnInit, AfterViewInit {

  public featuredProducts: Array<any>;
  constructor(private dashboardService: DashboardService) { }


  ngOnInit(): void {
    this.dashboardService.getJsonBasedOnFileName('/assets/data/feature-products.json').subscribe(data => {
      if (data) {
        this.featuredProducts = data;
      }
    });
  }

  ngAfterViewInit(): void {
    setTimeout(() => {
      jQuery('#riderCarousel.carousel .carousel-item').each(function () {
        let next = jQuery(this).next();
        if (!next.length) {
          next = jQuery(this).siblings(':first');
        }
        next.children(':first-child').clone().appendTo(jQuery(this));

        for (let i = 0; i < 2; i++) {

          next = next.next();
          if (!next.length) {
            next = jQuery(this).siblings(':first');
          }

          next.children(':first-child').clone().appendTo(jQuery(this));
        }
      });
      // Initialize the carousel with an interval
      jQuery('#riderCarousel').carousel({
        interval: 3000
      });
    }, 1000);
  }

}
