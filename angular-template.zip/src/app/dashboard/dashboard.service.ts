
import { of as observableOf, Observable } from 'rxjs';
import { Injectable, Inject } from '@angular/core';
import { HttpUtility } from '@core/utilities/http/http-utility.service';

@Injectable()
export class DashboardService {

    constructor(
        private http: HttpUtility
    ) {
    }

    getJsonBasedOnFileName(filePath: string): Observable<any> {
        return this.http.get(filePath);
    }

}
