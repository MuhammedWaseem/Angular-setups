import { Component, OnInit, ViewEncapsulation, Inject } from '@angular/core';
import { I18nService } from '@core/data/I18nService';
import { TranslateService } from '@ngx-translate/core';
import { UserService } from '@core/data/users.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class DashboardComponent implements OnInit {

  constructor(
    private i18nService: I18nService,
    private translate: TranslateService,
    private userService: UserService
  ) {
    const currentLanguage = this.userService.getCurrentLanguage();
    const dashboardPageTranslations = this.i18nService.getTranslationsByPageName('dashboardTranslations');
    this.translate.setTranslation(currentLanguage, dashboardPageTranslations, true);
  }

  ngOnInit(): void {
  }

}
