﻿import { Injectable } from '@angular/core';
import { Router, CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { AuthenticationService } from './authentication.service';
import { UserDataService } from '../../permissions/user-data.service';

@Injectable()
export class AuthenticationGuardService implements CanActivate {

    constructor(private _authService: AuthenticationService, private router: Router, private _userService: UserDataService) {
    }

    canActivate(): boolean {
        if (this._authService.isLoggedIn()) {
            const userRoleDetails = this._userService.getCurrentUser();
            if (!(userRoleDetails && userRoleDetails.userRoles && userRoleDetails.userRoles.length > 0)) {
                this._authService.signOut();
                return false;
            }
            return true;
        }
        this._authService.startAuthentication();
        return false;
    }
}
