import { Component } from '@angular/core';

@Component({
    selector: 'app-log-out',
    templateUrl: './log-out.component.html'
})
export class LogOutComponent {
}
