import { NgModule, ModuleWithProviders } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AuthenticationGuardService } from './auth-guard.service';
import { AuthenticationService } from './authentication.service';
import { AdalService } from './adal-angular/adal.service';
import { AuthCallbackComponent } from './auth-callback.component';
import { Routes, RouterModule } from '@angular/router';
import { LogOutComponent } from '@core/azure-ad/log-out.component';
import { UserDataService } from '../../permissions/user-data.service';
import { UserPermissionService } from '../../permissions/user-permission.service';

const SERVICES = [
    AuthenticationGuardService,
    AuthenticationService,
    UserDataService,
    UserPermissionService,
    AdalService
];


const routes: Routes = [
    { path: 'auth-callback', component: AuthCallbackComponent },
    { path: 'log-out', component: LogOutComponent }
];

@NgModule({
    imports: [
        CommonModule,
        RouterModule.forRoot(routes)
    ],
    declarations: [
        AuthCallbackComponent,
        LogOutComponent
    ],
    entryComponents: [
        AuthCallbackComponent,
        LogOutComponent
    ],
    providers: [
        ...SERVICES,
    ],
    exports: [AuthCallbackComponent]
})
export class AzureAdModule {
    static forRoot(): ModuleWithProviders {
        return <ModuleWithProviders>{
            ngModule: AzureAdModule,
            providers: [
                ...SERVICES,
            ],
        };
    }
}

