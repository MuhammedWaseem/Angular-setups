﻿import { AdalService } from './adal-angular/adal.service';
import { HttpClient, HttpHandler, HttpHeaders } from '@angular/common/http';
import { Router, ActivatedRoute } from '@angular/router';
import { Injectable } from '@angular/core';
import { Observable, Subject, throwError } from 'rxjs';
import { GlobalEventsManager } from '@core/data/global-events-manager';
import { environment } from '../../../environments/environment';
import { UserPermissionService } from '../../permissions/user-permission.service';
import { UserDataService } from '../../permissions/user-data.service';

const azureAd = environment.azureAd;

@Injectable()
export class AuthenticationService {
    private _user = null;
    private token: Observable<string>;
    private _config = {
        instance: azureAd.instance,
        tenantId: azureAd.tenantId,
        clientId: azureAd.clientId,
        redirectUri: azureAd.redirectUri,
        postLogoutRedirectUri: azureAd.postLogoutRedirectUri,
        endpoints: azureAd.endpoints,
        expireOffsetSeconds: 300
    };
    constructor(
        private _adal: AdalService,
        private _router: Router,
        private http: HttpClient,
        private globalEventsManager: GlobalEventsManager, private _userPermissionService: UserPermissionService, private userService: UserDataService) {
        this._adal.init(this._config);
        const userInfo = this._adal.userInfo;
        if (userInfo.authenticated) {
            this._user = this.getUserProfile();
        }
    }
    public isLoggedIn(): boolean {
        return this._adal.userInfo.authenticated;
    }
    public signOut(): void {
        this.userService.deleteUser();
        this.userService.deleteMenuSetup();
        this._adal.logOut();
    }
    public startAuthentication(): any {
        this._adal.login();
    }
    public getUserProfile(): object {
        return this._adal.userInfo.profile;
    }
    public getUserProfilePic() {
    }
    public getName(): string {
        return this._user.profile.name;
    }
    public completeAuthentication(): void {
        this._adal.handleWindowCallback();
        this._adal.getUser().subscribe(user => {
            this._user = this.getUserProfile();
            this.globalEventsManager.toggleLoader(true);
            this._userPermissionService.getLoggedInUserDetails().subscribe(
                res => {
                    this.globalEventsManager.toggleLoader(false);
                    this.userService.setCurrentUser(res);
                    this.globalEventsManager.isUserLoggedIn(true);
                    const currentRouteItem = sessionStorage.getItem('currentRoute');
                    if (currentRouteItem) {
                        this._router.navigate([currentRouteItem]);
                    } else {
                        this._router.navigate(['/dashboard']);
                    }

                },
                (error) => {
                    this.globalEventsManager.toggleLoader(false);
                    this.signOut();
                }
            );
        });
    }

    public getToken(): Observable<string> {
        const resource = this._adal.getResourceForEndpoint(azureAd.tenantId);
        if (resource) {
            if (this._adal.userInfo.authenticated) {
                this.token = this._adal.acquireToken(resource);
            } else {
                this.token = this._adal.acquireToken(resource);
            }
            return this.token;
        }
        return throwError('No Resource Found');
    }
}
