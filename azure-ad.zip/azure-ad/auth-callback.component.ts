import { Router, ActivatedRoute } from '@angular/router';
import { Component, OnInit, NgZone } from '@angular/core';
import { AuthenticationService } from './authentication.service';

@Component({
    selector: 'app-auth-callback',
    templateUrl: './auth-callback.component.html'
})

export class AuthCallbackComponent implements OnInit {

    constructor(
        private _authService: AuthenticationService
    ) { }

    ngOnInit() {
        this._authService.completeAuthentication();
    }
}
